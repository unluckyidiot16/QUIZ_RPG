export declare const sb: import("@supabase/supabase-js").SupabaseClient<any, "public", "public", any, any>;
