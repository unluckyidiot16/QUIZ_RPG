export default function AccessControl(): import("react/jsx-runtime").JSX.Element;
