export default function AdminTokens(): import("react/jsx-runtime").JSX.Element;
