export default function Runs(): import("react/jsx-runtime").JSX.Element;
