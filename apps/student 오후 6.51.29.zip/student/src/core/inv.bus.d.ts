export declare const notifyInventoryChanged: () => boolean;
export declare const onInventoryChanged: (cb: () => void) => () => void;
