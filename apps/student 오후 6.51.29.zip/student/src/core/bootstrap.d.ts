export declare function bootstrapFirstRun(): Promise<void>;
