import type { ItemCatalog } from './wearable.types';
export declare function loadWearablesCatalog(): Promise<ItemCatalog>;
export declare const loadWearablesCatalogFromSheet: typeof loadWearablesCatalog;
