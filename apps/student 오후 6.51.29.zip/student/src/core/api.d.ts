export declare function guestLogin(token: string): Promise<string>;
export declare function getUserId(): string | null;
export declare function enterDungeon(): Promise<string>;
export declare function ensureRunToken(): Promise<string>;
