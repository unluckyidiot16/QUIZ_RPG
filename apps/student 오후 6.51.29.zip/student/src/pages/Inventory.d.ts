export default function Inventory(): import("react/jsx-runtime").JSX.Element;
