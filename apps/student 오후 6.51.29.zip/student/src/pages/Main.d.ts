export default function Main(): import("react/jsx-runtime").JSX.Element;
