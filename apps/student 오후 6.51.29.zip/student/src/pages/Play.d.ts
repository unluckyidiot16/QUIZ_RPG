export default function Play(): import("react/jsx-runtime").JSX.Element;
