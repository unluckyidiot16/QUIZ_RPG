export default function Result(): import("react/jsx-runtime").JSX.Element;
