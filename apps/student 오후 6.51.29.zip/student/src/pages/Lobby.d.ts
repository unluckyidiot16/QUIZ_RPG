export default function Lobby(): import("react/jsx-runtime").JSX.Element;
