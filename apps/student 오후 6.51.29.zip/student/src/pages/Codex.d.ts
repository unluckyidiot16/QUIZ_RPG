export default function Codex(): import("react/jsx-runtime").JSX.Element;
