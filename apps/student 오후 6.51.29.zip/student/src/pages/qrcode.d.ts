declare module 'qrcode' { const x: any; export default x; }
