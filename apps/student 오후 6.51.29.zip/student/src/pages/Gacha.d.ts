export default function Gacha(): import("react/jsx-runtime").JSX.Element;
