/** ─ Component ─ */
export default function Wardrobe(): import("react/jsx-runtime").JSX.Element;
