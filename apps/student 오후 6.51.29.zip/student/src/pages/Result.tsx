// apps/student/src/pages/Result.tsx
import { useNavigate } from 'react-router-dom';
import { useEffect, useMemo, useState } from 'react';
import { newRunToken, resetLocalRunState, ensureRunToken, finishDungeon, type RunSummary } from '../api';
import { initQueue, enqueue } from '../shared/lib/queue';

type Resp = { ok: true; idempotent: boolean } | null;

export default function Result() {
  const nav = useNavigate();

  // 오프라인 재시도 큐 가동
  useEffect(() => { initQueue(finishDungeon); }, []);

  async function restart() {
    await newRunToken();
    resetLocalRunState();
    nav('/play', { replace: true });
  }

  function goHome() {
    resetLocalRunState();
    nav('/', { replace: true });
  }

  // 저장된 결과 읽기 — 객체/배열 모두 허용
  const raw = localStorage.getItem('qd:lastResult');
  const parsed: any = useMemo(() => (raw ? JSON.parse(raw) : null), [raw]);

  // 호환: 배열(턴 로그)로 저장된 옛 포맷도 요약으로 변환
  const data: Omit<RunSummary, 'runToken' | 'finalHash'> | null = useMemo(() => {
    if (!parsed) return null;
    if (Array.isArray(parsed)) {
      const turns = parsed;
      const total = turns.length || 0;
      const correct = turns.filter((t: any) => t?.correct).length;
      const cleared = correct >= Math.ceil(Math.max(1, total) * 0.6);
      const durationSec = Number(localStorage.getItem('qd:lastDurationSec') || '0') || 0;
      return { cleared, turns: total, durationSec };
    }
    // 객체 포맷
    const { cleared, turns, durationSec } = parsed;
    if (typeof turns === 'number') {
      return {
        cleared: Boolean(cleared),
        turns: Math.max(0, turns|0),
        durationSec: Math.max(0, Number(durationSec) || 0),
      };
    }
    return null;
  }, [parsed]);

  const [resp, setResp] = useState<Resp>(null);
  const [submitting, setSubmitting] = useState(false);

  async function submit() {
    if (!data || submitting) return;
    setSubmitting(true);
    let runToken: string;
    try {
      runToken = await ensureRunToken();
    } catch (e) {
      console.error('enter_dungeon failed', e);
      setSubmitting(false);
      alert('던전 입장 토큰 발급 실패: 서버 연결을 확인해주세요.');
      return;
    }

    const summary: RunSummary = { ...data, runToken, finalHash: '' };
    try {
      const r = await finishDungeon(summary);
      setResp(r);
    } catch (e) {
      enqueue(summary);
      console.error('finish_dungeon failed', e);
      alert('오프라인/오류: 네트워크 복구 시 자동 재시도합니다.');
    } finally {
      setTimeout(() => setSubmitting(false), 1200);
    }
  }

  async function resubmitSameToken() {
    if (!data || submitting) return;
    const runToken = localStorage.getItem('qd:runToken');
    if (!runToken) {
      alert('runToken이 없어 재제출을 할 수 없어요. 먼저 "제출"을 한 번 눌러주세요.');
      return;
    }
    setSubmitting(true);
    const summary: RunSummary = { ...data, runToken, finalHash: '' };
    try {
      const r = await finishDungeon(summary);
      setResp(r);
    } catch (e) {
      enqueue(summary);
      console.error('resubmit failed', e);
      alert('오프라인/오류: 네트워크 복구 시 자동 재시도합니다.');
    } finally {
      setTimeout(() => setSubmitting(false), 800);
    }
  }

  if (!data) return <div className="p-6">기록이 없어요.</div>;

  return (
    <div className="p-6 max-w-xl mx-auto space-y-4">
      <h2 className="text-2xl font-bold">결과</h2>

      <div className="p-4 bg-slate-800 rounded space-y-2">
        <div>클리어: {data.cleared ? '성공' : '실패'}</div>
        <div>턴 수: {data.turns}</div>
        <div>소요 시간(초): {data.durationSec}</div>

        <div className="pt-2 flex gap-2">
          <button
            disabled={submitting}
            onClick={submit}
            className={`px-3 py-2 rounded ${submitting ? 'opacity-50 cursor-not-allowed bg-slate-600' : 'bg-emerald-600 hover:bg-emerald-500'}`}
          >
            {submitting ? '처리 중…' : '제출'}
          </button>

          <button
            disabled={submitting}
            onClick={resubmitSameToken}
            className="px-3 py-2 rounded bg-slate-700 hover:bg-slate-600"
          >
            재제출 테스트
          </button>
        </div>

        {resp && (
          <div className={`mt-2 inline-flex items-center gap-2 px-2 py-1 rounded text-sm ${
            resp.idempotent ? 'bg-slate-700' : 'bg-emerald-700'
          }`}>
            <span className="font-semibold">
              {resp.idempotent ? '이미 제출됨(멱등 처리)' : '제출 완료'}
            </span>
            <span className="opacity-80">idempotent=<b>{String(resp.idempotent)}</b></span>
          </div>
        )}
      </div>

      <div className="mt-6 flex gap-3">
        <button className="px-4 py-2 bg-emerald-600 rounded" onClick={restart}>다시하기</button>
        <button className="px-4 py-2 bg-slate-700 rounded" onClick={goHome}>메인</button>
      </div>
    </div>
  );
}
