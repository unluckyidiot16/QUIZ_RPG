export default function TokenGatePage(): import("react/jsx-runtime").JSX.Element;
