export declare function preloadImages(urls: string[]): Promise<unknown[]>;
