export declare function newIdempotencyKey(prefix?: string): string;
