export default function AppHeader(): import("react/jsx-runtime").JSX.Element;
